import kaplay from "https://unpkg.com/kaplay@3001.0.19/dist/kaplay.mjs";

kaplay({
  width:      800,
  height:     450,
  letterbox:  true, 
  background: [20, 20, 30],
  debug:      false,
});

// assets
// ── Sons ──────────────────────────────────────────────────────────────────────
loadSound("gunshot",    "gunshot.wav");
loadSound("transform",  "transform.mp3");
loadSound("gamemusic",  "awake10_megaWall.mp3");

// ── Décors niveau 1 ───────────────────────────────────────────────────────────
loadSprite("log_platform", "log_platform.png");
loadSprite("background",  "background.png");
loadSprite("background2",  "background2.png");
loadSprite("background3", "background3.png");
loadSprite("background4", "background4.png");


loadSprite("sauterelle",   "sauterelle.png", {
  sliceX: 2,
  sliceY: 3,
  anims: {
    "idle": { from: 0, to: 2, loop: true, speed: 14 },
    "run":  { from: 3, to: 5, loop: true, speed: 20 },
  }
});
loadSprite("grenouille", "grenouille.png",{
})
loadSprite("serpent", "serpent.png",{
})
loadSprite("aigle", "aigle.png",{
})
loadSprite("chasseur", "chasseur.png",{
})
loadSprite("cactus", "cactus.png",{
})
loadSprite("rocher_s", "rocher_s.png");
loadSprite("rocher_m", "rocher_m.png");
loadSprite("rocher_l", "rocher_l.png");
loadSprite("scorpion", "scorpion.png", {
  sliceX: 2,
  sliceY: 2,
  anims: {
    "idle": { from: 0, to: 2, loop: true },
    "warn": { from: 0, to: 2, loop: true },
  }
});
loadSprite("nenuphar", "nenuphar.png", {
  sliceX: 3,
  sliceY: 1,
  anims: {
    "idle": { from: 0, to: 2, loop: true, speed: 3 },  // oscillation lente
  }
});


// fonction réutilisée
function addPlateforme(x, y, w, h, col) {
  return add([
    rect(w, h), pos(x, y),
    area(), body({ isStatic: true }),
    color(...col), "ground",
  ]);
}

function flashTransition(couleur, cb) {
  const overlay = add([
    rect(width(), height()),
    color(...couleur),
    opacity(0), fixed(), z(100),
  ]);
  tween(0, 1, 0.25, (v) => (overlay.opacity = v));
  wait(0.5, cb);
}

// IA de chasse — le prédateur fonce vers le joueur et accélère
function makePredatorChase(predator, getPlayer, baseSpeed, accel) {
  let elapsed = 0;
  onUpdate(() => {
    elapsed += dt();
    const player = getPlayer();
    if (!player || !player.exists()) return;
    const currentSpeed = baseSpeed + elapsed * accel;
    const dir = player.pos.sub(predator.pos).unit();
    predator.move(dir.scale(currentSpeed));
  });
}

// ── Scène de démarrage ───────────────────────────────────────────────────────
scene("start", () => {
  add([rect(width(), height()), color(15, 30, 15), fixed()]);

  // Titre
  add([
    text("Chain", { size: 58 }),
    pos(center().x, center().y - 80),
    anchor("center"),
    color(168, 212, 90),
  ]);

  // Sous-titre
  add([
    text("une histoire de chaîne alimentaire", { size: 13 }),
    pos(center().x, center().y - 35),
    anchor("center"),
    color(100, 160, 100),
  ]);

  // Description
  add([
    text("Tu es la proie.\nÉvite le prédateur en survivant le plus longemps possible\njusqu'à te faire attraper.", {
       size: 16,
       width: 600,
       align: "center",}),
    pos(center().x, center().y + 30),
    anchor("center"),
    color(200, 200, 200),
  ]);

  // Règle clé
  add([
    text("Se faire manger = évoluer", { size: 14 }),
    pos(center().x, center().y + 95),
    anchor("center"),
    color(150, 200, 150),
  ]);

  // Appel à l'action
  add([
    text("— Appuie sur ESPACE pour commencer —", { size: 14 }),
    pos(center().x, center().y + 145),
    anchor("center"),
    color(80, 130, 80),
  ]);


  

  onKeyPress("space", () => {
    play("gamemusic", { loop: true, volume: 0.3 });
    go("1");
  });
});

// ── Scène de fin ─────────────────────────────────────────────────────────────
scene("end", () => {
  add([rect(width(), height()), color(18, 18, 28), fixed()]);

  add([
    text("La chaîne est brisée.", { size: 42 }),
    pos(center().x, center().y - 80), anchor("center"),
    color(255, 100, 80),
  ]);

  add([
    text("L'humain est ancré dans la chaîne alimentaire,\nmais son empreinte bouscule tous les équilibres naturels.\nPlus qu'un simple maillon, il est celui qui brise le cycle.", { size: 15 }),
    pos(center().x, center().y), anchor("center"),
    color(200, 180, 160),
  ]);

  add([
    text("c'est la fin", { size: 22 }),
    pos(center().x, center().y + 70), anchor("center"),
    color(168, 212, 90),
  ]);

  // Temps de survie total accumulé
  add([
    text(`⏱  Tu as survécu  ${Math.floor(totalSurvivalTime)} secondes  au total.`, { size: 16 }),
    pos(center().x, center().y + 115), anchor("center"),
    color(255, 220, 100),
  ]);

  add([
    text("ESPACE pour rejouer", { size: 15 }),
    pos(center().x, center().y + 155), anchor("center"),
    color(110, 110, 110),
  ]);

  onKeyPress("space", () => {
    totalSurvivalTime = 0;  // reset pour la prochaine partie
    go("start");
  });
});


  // scene 1
scene("1", () => {
  const SPEED      = 150;
  const JUMP_FORCE = 500;
  setGravity(850);

  // Fond niveau 1
  add([
    sprite("background"),
    pos(0, 0),
    scale(1),
    fixed(),
  ]);

  // Plateformes avec sprite tronc
  addPlateforme(0,   415, 800, 35, [30, 80, 30]);   // sol invisible
  
  function addLog(x, y, w) {
    addPlateforme(x, y, w, 0.1, [0, 0, 0, 0]);
    const count = Math.ceil(w / 40);
    for (let i = 0; i < count; i++) {
      add([
        sprite("log_platform"),
        pos(x + i * 40, y - 20),
        anchor("topleft"),
        scale(0.4),
        z(1),
      ]);
    }
  }

  addLog(50,  310, 140);
  addLog(280, 250, 140);
  addLog(500, 310, 140);
  addLog(650, 190, 140);
  addLog(130, 170, 120);
  addLog(350, 130, 100);



  //player
  const player = add([
    sprite("sauterelle"),
    pos(60, 430),
     area(),
     body(),
    scale(1), 
    anchor("bot"),
    "player",

  ]);

  player.play("idle");

  // prédateur
    const predator = add([
    sprite("grenouille"),
    pos(700, 390), area(),
    scale(0.2), anchor("botleft"),
    "predator",
  ]);

  //déplacement grenouille
  onUpdate(() => {
    predator.pos.y = height() - 45;
    const dx = player.pos.x - predator.pos.x;
    predator.move(dx > 0 ? 45 : -45, 0);
    predator.flipX = dx < 0;
  });

  // tirer la langue de la grenouille
   let tongueCooldown = 2;
  const TONGUE_RANGE = 250;  // portée max de la langue

  onUpdate(() => {
    tongueCooldown -= dt();
    if (tongueCooldown <= 0) {
      tongueCooldown = 2 + Math.random() * 1; // entre 2 et 3s
      const dist = player.pos.dist(predator.pos);

      if (dist < TONGUE_RANGE) {
        // Direction vers le joueur
        const dir = player.pos.sub(predator.pos).unit();

        const tongue = add([
          rect(20, 5),
          pos(predator.pos.x + (predator.flipX ? -10 : 20), predator.pos.y - 12),
          area(),
          color(220, 60, 80),
          rotate(Math.atan2(dir.y, dir.x) * (180 / Math.PI)),
          "tongue",
        ]);

          let traveled = 0;
        tongue.onUpdate(() => {
          const step = 280 * dt();
          tongue.move(dir.x * 280, dir.y * 280);
          traveled += step;
          if (traveled > TONGUE_RANGE || !tongue.exists()) destroy(tongue);
        });

        wait(0.8, () => { if (tongue.exists()) destroy(tongue); });
      }
    }
  });

  addSurvivalTimer();

  player.onCollide("tongue", () => {
    play("transform");
    flashTransition([80, 200, 80], () => go("trans1"));
  });

  player.onCollide("predator", () => {
    play("transform");
    flashTransition([80, 200, 80], () => go("trans1"));
  });


  onKeyDown("left",  () => { player.move(-SPEED, 0); player.flipX = true; if (player.curAnim() !== "run") player.play("run"); });
  onKeyDown("right", () => { player.move(SPEED,  0); player.flipX = false;  if (player.curAnim() !== "run") player.play("run"); });
  onKeyPress("up", () => { if (player.isGrounded()) player.jump(JUMP_FORCE); });

})

// scene 2 
scene("2", () => {
  const SPEED  = 150;
  const JUMP_FORCE = 600;
  const SINK_TIME = 5;
  const SINK_DIST = 40;
  setGravity(850);
 
  add([
    sprite("background2"),
    pos(0, 0),
    scale(0.9),
    fixed(),
  ]);
 
  //niveau
  addPlateforme(0, 415, 800, 35, [140, 100, 50]);
 
  const LEAVES = [
    { x: 30,  y: 340, w: 130 },
    { x: 220, y: 275, w: 120 },
    { x: 400, y: 210, w: 110 },
    { x: 570, y: 270, w: 130 },
    { x: 650, y: 175, w: 140 },
    { x: 100, y: 180, w: 110 },
    { x: 310, y: 140, w: 100 },
  ];
 
  // Les feuilles n'ont PAS de body — collision manuelle pour pouvoir
  // laisser le joueur passer à travers quand elles sont trop affaissées.
  const leaves = LEAVES.map(({ x, y, w }) => ({
    baseY:         y,
    x,
    w,
    sinkProgress:  0,
    sinking:       false,
    recovering:    false,
    recoveryTimer: 0,
    obj: add([
      sprite("nenuphar"),
      scale(0.38),
      pos(x, y),
      anchor("topleft"),
      z(1),
    ]),
  }));

  leaves.forEach(leaf => leaf.obj.play("idle"));
 
  // joueur — déclaré AVANT onUpdate pour être accessible dans la boucle
  const player = add([
    sprite("grenouille"),
    pos(60, 370), area(), body(),
    scale(0.2),
    { jumpsLeft: 1, inWater: false },
  ]);
 
  const WATER_Y = height() - 60;
 
  onUpdate(() => {
    leaves.forEach((leaf) => {
      // La feuille devient passante à partir de 90% d'affaissement
      const passthrough = leaf.sinkProgress >= 0.9;
 
      // Collision manuelle : bloque le joueur uniquement si la feuille est active
      const playerBottom = player.pos.y;
      const playerLeft   = player.pos.x;
      const playerRight  = player.pos.x + 18;
      const leafTop      = leaf.obj.pos.y;
 
      const landing =
        !passthrough &&
        player.vel.y >= 0 &&
        playerBottom >= leafTop - 6 &&
        playerBottom <= leafTop + 14 &&
        playerRight  > leaf.x &&
        playerLeft   < leaf.x + leaf.w;
 
      if (landing) {
        player.pos.y = leafTop;
        player.vel.y = 0;
        leaf.sinking = true;
        player.jumpsLeft = 1;
      }
 
      // ── Affaissement progressif ───────────────────────────────────────────
      if (leaf.sinking && !leaf.recovering) {
        leaf.sinkProgress = Math.min(1, leaf.sinkProgress + dt() / SINK_TIME);
        const ny = leaf.baseY + leaf.sinkProgress * SINK_DIST;
        leaf.obj.pos.y  = ny;

        leaf.obj.opacity  = 1 - leaf.sinkProgress * 0.7;

        if (leaf.sinkProgress >= 1) {
          leaf.sinking       = false;
          leaf.recovering    = true;
          leaf.recoveryTimer = SINK_TIME;
        }
      }

      // ── Récupération ─────────────────────────────────────────────────────
      if (leaf.recovering) {
        leaf.recoveryTimer -= dt();
        if (leaf.recoveryTimer <= 0) {
          leaf.sinkProgress = Math.max(0, leaf.sinkProgress - dt() * 0.4);
          const ny = leaf.baseY + leaf.sinkProgress * SINK_DIST;
          leaf.obj.pos.y  = ny;
          leaf.obj.opacity  = 1 - leaf.sinkProgress * 0.7;

          if (leaf.sinkProgress <= 0) {
            leaf.recovering   = false;
            leaf.sinking      = false;
            leaf.obj.opacity  = 1;
          }
        }
      }
    });
 
    // Gestion de l'eau : amortit la chute + permet de ressauter
    player.inWater = player.pos.y >= WATER_Y - 10;
    if (player.inWater) {
      player.vel.y   *= 0.75;
      player.jumpsLeft = 1;
    }
  });
 
 
  const predator = add([
    sprite("serpent"),
    pos(720, height() - 80), area(),
    scale(0.9), anchor("botleft"),
    "predator",
  ]);
 
  let snakeDir = -1;
  onUpdate(() => {
    predator.pos.y = height() - 22;
    predator.move(snakeDir * 60, 0);
    predator.flipX = snakeDir < 0;
    if (predator.pos.x < 10 || predator.pos.x > width() - 60) snakeDir *= -1;
  });
 
  onKeyDown("left",  () => { player.move(-SPEED, 0); player.flipX = true;  });
  onKeyDown("right", () => { player.move(SPEED,  0); player.flipX = false; });
  onKeyPress("up", () => {
    if (player.isGrounded() || player.jumpsLeft > 0 || player.inWater) {
      player.jump(JUMP_FORCE);
      player.jumpsLeft = Math.max(0, player.jumpsLeft - 1);
    }
  });
  player.onGround(() => { player.jumpsLeft = 1; });
 
  addSurvivalTimer();

  player.onCollide("predator", () => {
    play("transform");
    flashTransition([160, 90, 20], () => go("trans2"));
  });

})

scene("snake", () => {
  const SPEED_BASE = 240;
  setGravity(900);
 
  // Arrière-plan désert
  add([
    sprite("background3"),
    pos(0, 0),
    scale(1),
    fixed(),
  ]);
  // Sol
  addPlateforme(0, 415, 800, 35, [140, 100, 50]);
 
  // Rochers — coordonnées réelles pour la logique de couverture
  // Le sprite est placé à x + w/2 avec anchor "bot" et scale 0.9
  const rocks = [
    { x: 60,  y: 415, w: 90,  h: 85, sprite: "rocher_l" },
    { x: 280, y: 415, w: 100, h: 90, sprite: "rocher_m" },
    { x: 500, y: 415, w: 90,  h: 85, sprite: "rocher_m" },
    { x: 660, y: 415, w: 130, h: 95, sprite: "rocher_l" },
  ];
  rocks.forEach(({ x, y, w, sprite: spr }) => {
    add([
      sprite(spr),
      pos(x + w / 2, y),
      anchor("bot"),
      scale(0.9),
    ]);
  });
 
  // Cactus
  [[190, 370], [450, 375], [600, 368]].forEach(([x, y]) => {
    add([
        sprite("cactus"),
        pos(x, y),
        scale(1),        // ajuste la taille
        anchor("bot"),
    ]);
  });
 
  // Joueur — Serpent
  const player = add([
    sprite("serpent"),
    pos(60, 400), area(), body(),
    scale(0.5), anchor("botleft"),
    "player",
  ]);
 
  // Prédateur — Aigle (pas de area/body — mouvement 100% manuel)
  const predator = add([
    sprite("aigle"),
    pos(400, 60),
    scale(1),
    anchor("center"),
    "predator",
  ]);

  let eagleState  = "circle";
  let circleAngle = 0;
  let circleTimer = 3;
  let diveTarget  = vec2(0, 0);
  let diveSpeed   = 0;
  const CX = 400, CY = 80, CR = 140;

  // ── Scorpions sous les rochers ──────────────────────────────────────────────
  // ── Scorpion — apparaît à côté du joueur après 5s immobile ──────────────────
  let stillTimer = 0;
  let lastX      = 0;
  let sc         = null;

  player.onCollide("scorpion", () =>
    flashTransition([200, 80, 20], () => go("trans3"))
  );

  onUpdate(() => {
    const moved = Math.abs(player.pos.x - lastX) > 3;
    lastX = player.pos.x;

    if (moved) {
      // Le joueur bouge → scorpion disparaît, timer reset
      stillTimer = 0;
      if (sc && sc.exists()) { destroy(sc); sc = null; }
      return;
    }

    // Seulement sous un rocher
    const underRock = rocks.some(r =>
      player.pos.x >= r.x && player.pos.x <= r.x + r.w
    );
    if (!underRock) { stillTimer = 0; return; }

    stillTimer += dt();

    // Après 5s : scorpion d'avertissement
    if (stillTimer >= 5 && stillTimer < 8 && !sc) {
      sc = add([
        sprite("scorpion"),
        pos(player.pos.x + 180, player.pos.y),
        anchor("bot"),
        scale(0.5),
        opacity(0.5),
        "scorpion_warn",
      ]);
      sc.play("idle");
    }

    // Met à jour la position du scorpion d'avertissement avec le joueur
    if (sc && sc.exists() && sc.is("scorpion_warn")) {
      sc.pos.x = player.pos.x + 180;
      sc.pos.y = player.pos.y;
    }

    // Après 8s : détruire l'avertissement et créer le scorpion dangereux
    if (stillTimer >= 8 && sc && sc.is("scorpion_warn")) {
      destroy(sc); sc = null;
    }
    if (stillTimer >= 8 && !sc) {
      sc = add([
        sprite("scorpion"),
        pos(player.pos.x + 180, player.pos.y),
        anchor("bot"),
        scale(0.6),
        "scorpion_danger",
      ]);
      sc.play("idle");
      stillTimer = 0;
    }

    // Le scorpion dangereux marche vers le joueur
    if (sc && sc.exists() && sc.is("scorpion_danger")) {
      const dx = player.pos.x - sc.pos.x;
      sc.move(dx > 0 ? 80 : -80, 0);
      sc.flipX = dx > 0;
      sc.pos.y = player.pos.y;   // reste au sol

      // Détection par distance — pas besoin de area()
      if (Math.abs(dx) < 25) {
        play("transform");
        flashTransition([200, 80, 20], () => go("trans3"));
      }
    }
  });

  onUpdate(() => {
    if (eagleState === "circle") {
      circleAngle += dt() * 1.5;
      predator.pos.x = CX + Math.cos(circleAngle) * CR;
      predator.pos.y = CY + Math.sin(circleAngle) * 35;
      predator.flipX = Math.cos(circleAngle) < 0;
      circleTimer -= dt();
      if (circleTimer <= 0) {
        // Piquer même si sous un rocher — l'aigle cible la dernière position
        eagleState  = "dive";
        diveTarget  = vec2(player.pos.x, player.pos.y);
        diveSpeed   = 320;
        circleTimer = 3 + Math.random() * 2;
      }
    }

    if (eagleState === "dive") {
      const dir = diveTarget.sub(predator.pos).unit();
      predator.move(dir.scale(diveSpeed));
      diveSpeed = Math.min(diveSpeed + 180 * dt(), 480);

      // Arrêt du piqué : cible atteinte OU trop bas
      // Ne s'arrête PLUS si joueur à l'abri — l'aigle va jusqu'au bout
      const reachedTarget = predator.pos.dist(diveTarget) < 30;
      const tooLow        = predator.pos.y > 390;

      if (reachedTarget || tooLow) {
        eagleState  = "circle";
        circleAngle = Math.atan2(predator.pos.y - CY, predator.pos.x - CX);
        if (tooLow) predator.pos.y = CY;
      }

      // Collision manuelle uniquement hors rocher
      const underRock = rocks.some(r =>
        player.pos.x >= r.x - 5 && player.pos.x <= r.x + r.w + 5
      );
      if (!underRock && predator.pos.dist(player.pos) < 35) {
        play("transform");
        flashTransition([210, 160, 40], () => go("trans3"));
      }
    }

  });
 
  // Contrôles — horizontal uniquement
  let speedBoost = 0;
  onKeyDown("left", () => {
    speedBoost = Math.min(speedBoost + dt() * 400, 100);
    player.move(-(SPEED_BASE + speedBoost), 0);
    player.flipX = true;
  });
  onKeyDown("right", () => {
    speedBoost = Math.min(speedBoost + dt() * 400, 100);
    player.move((SPEED_BASE + speedBoost), 0);
    player.flipX = false;
  });
  onKeyRelease("left",  () => { speedBoost = 0; });
  onKeyRelease("right", () => { speedBoost = 0; });
 
  onUpdate(() => {
    player.pos.x = clamp(player.pos.x, 0, width() - 50);
  });
 
  addSurvivalTimer();
 
  player.onUpdate(() => {
    if (player.pos.y > height() + 60) player.pos = vec2(60, 400);
  });
});

scene("eagle", () => {
  setGravity(0);

    add([
    sprite("background4"),
    pos(0, 0),
    scale(0.8),
    fixed(),
  ]);
  
  addPlateforme(0, 395, 800, 65, [140, 100, 50]);

  // ── Aigle — vole librement en cinématique ─────────────────────────────────
  const eagle = add([
    sprite("aigle"),
    pos(60, 200),
    scale(0.8),
    anchor("center"),
    z(5),   // au-dessus du fond, sous le flash
  ]);

  // Trajectoire de vol libre : courbe sinusoïdale paisible
  let t = 0;
  let phase = "fly";       // "fly" → "shot" → "fall" → "end"
  let fallVel = 0;
  let shotTimer = 0;

  // ── Texte cinématique ─────────────────────────────────────────────────────
  const caption = add([
    text("", { size: 16, width: 600 }),
    pos(center().x, height() - 30),
    anchor("center"),
    color(255, 255, 255),
    opacity(0),
    fixed(), z(10),
  ]);

  function showCaption(txt, duration, cb) {
    caption.text = txt;
    tween(0, 1, 0.5, (v) => (caption.opacity = v));
    wait(duration - 0.5, () => {
      tween(1, 0, 0.5, (v) => (caption.opacity = v));
      if (cb) wait(0.5, cb);
    });
  }

  // ── Humain — apparaît plus tard ───────────────────────────────────────────
  const human = add([
    sprite("chasseur"),
    pos(750, height() - 55),
    scale(2),
    anchor("bot"),
    opacity(0),
  ]);

  // Flash de tir
  const muzzle = add([
    rect(width(), height()),
    color(255, 255, 200),
    opacity(0),
    fixed(), z(50),
  ]);

  // ── Séquence cinématique ──────────────────────────────────────────────────
  // Acte 1 : vol libre — sentiment de liberté (3s)
  showCaption("Tu es au sommet. Le ciel t'appartient.", 3, () => {

    // Acte 2 : l'humain apparaît (2s)
    tween(0, 1, 1, (v) => (human.opacity = v));
    showCaption("Mais quelque chose bouge en bas...", 2.5, () => {

      // Acte 3 : coup de feu — flash brutal
      phase = "shot";
      play("gunshot", { volume: 0.8 });
      tween(0, 0.8, 0.08, (v) => (muzzle.opacity = v), easings.linear);
      tween(0.8, 0, 0.15, (v) => (muzzle.opacity = v), easings.linear);

      showCaption("💥", 0.5, () => {

        // Acte 4 : l'aigle tombe
        phase = "fall";
        showCaption("L'humain est ancré dans la chaîne alimentaire, mais son empreinte bouscule tous les équilibres naturels. Plus qu'un simple maillon, il est celui qui brise le cycle..", 8, () => {

          // Acte 5 : fondu au noir → écran de fin
          const blackout = add([
            rect(width(), height()),
            color(0, 0, 0),
            opacity(0),
            fixed(), z(90),
          ]);
          tween(0, 1, 1.5, (v) => (blackout.opacity = v));
          wait(1.5, () => go("end"));
        });
      });
    });
  });

  // ── Boucle de mise à jour cinématique ────────────────────────────────────
  onUpdate(() => {
    t += dt();

    if (phase === "fly") {
      // Vol paisible en S
      eagle.pos.x = 60  + t * 60;
      eagle.pos.y = 180 + Math.sin(t * 1.2) * 50;
      // Reboucle sur l'écran
      if (eagle.pos.x > width() + 40) eagle.pos.x = -40;
    }

    if (phase === "shot") {
      // L'aigle s'arrête net — secousse
      eagle.pos.x += Math.sin(t * 80) * 3;
      eagle.pos.y += Math.sin(t * 80) * 3;
      shotTimer += dt();
      if (shotTimer > 0.3) phase = "fall";
    }

    if (phase === "fall") {
      fallVel += dt() * 300;
      eagle.pos.y += fallVel * dt();
      // Retourner l'aigle tête en bas avec flipY
      eagle.flipY = true;
    }
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// TRANSITIONS NARRATIVES
// ─────────────────────────────────────────────────────────────────────────────

// ── Timer de survie global — s'accumule sur tous les niveaux ─────────────────
let totalSurvivalTime = 0;

function addSurvivalTimer() {
  const label = add([
    text("⏱ 0s", { size: 13 }),
    pos(width() - 10, 10),
    anchor("topright"),
    color(255, 220, 100),
    fixed(), z(50),
  ]);

  onUpdate(() => {
    totalSurvivalTime += dt();
    label.text = `⏱ ${Math.floor(totalSurvivalTime)}s`;
  });
}

function makeTransition(narratif, fait, animal, couleurFond, couleurTexte, nextScene) {
  add([rect(width(), height()), color(...couleurFond), fixed()]);

  // Texte narratif
  const msg = add([
    text(narratif, { size: 19, width: 580, align: "center" }),
    pos(center().x, center().y - 60),
    anchor("center"),
    color(...couleurTexte),
    opacity(0), fixed(), z(10),
  ]);

  // Séparateur
  const sep = add([
    rect(400, 1),
    pos(center().x - 200, center().y + 10),
    color(...couleurTexte),
    opacity(0), fixed(), z(10),
  ]);

  // Label "Le savais-tu ?"
  const label = add([
    text(`🔎  Le savais-tu — ${animal}`, { size: 11 }),
    pos(center().x, center().y + 25),
    anchor("center"),
    color(...couleurTexte),
    opacity(0), fixed(), z(10),
  ]);

  // Fait scientifique
  const factMsg = add([
    text(fait, { size: 14, width: 560, align: "center" }),
    pos(center().x, center().y + 65),
    anchor("center"),
    color(...couleurTexte),
    opacity(0), fixed(), z(10),
  ]);

  // Hint
  const hint = add([
    text("— Appuie sur ESPACE pour continuer —", { size: 12 }),
    pos(center().x, height() - 35),
    anchor("center"),
    color(...couleurTexte),
    opacity(0), fixed(), z(10),
  ]);

  // Animations
  tween(0, 1, 1.2, (v) => {
    msg.opacity   = v;
    sep.opacity   = v * 0.5;
    label.opacity = v;
    factMsg.opacity = v;
  });
  wait(1.5, () => tween(0, 0.7, 0.8, (v) => (hint.opacity = v)));

  onKeyPress("space", () => go(nextScene));
}

// ── Transition 1 : Insecte → Grenouille ──────────────────────────────────────
scene("trans1", () => {
  makeTransition(
    "Tu as été avalé.\nMais quelque chose a changé.\nTu es plus grand. Plus fort.\nLa chaîne tourne.",
    "La sauterelle peut sauter jusqu'à 20 fois\nla longueur de son propre corps.\nElle perçoit les vibrations du sol\navant même d'entendre le prédateur.",
    "La Sauterelle",
    [15, 45, 15],
    [150, 220, 130],
    "2"
  );
});

// ── Transition 2 : Grenouille → Serpent ──────────────────────────────────────
scene("trans2", () => {
  makeTransition(
    "La mare était ton monde.\nElle ne l'est plus.\nUn autre règne ici maintenant —\net c'est toi.",
    "La grenouille attrape ses proies\ngrâce à une langue collante projetée\nen moins de 0.07 secondes —\nplus rapide que le clignement d'un œil.",
    "La Grenouille",
    [20, 20, 35],
    [160, 200, 255],
    "snake"
  );
});

// ── Transition 3 : Serpent → Aigle ───────────────────────────────────────────
scene("trans3", () => {
  makeTransition(
    "Tu as rampé.\nTu as survécu.\nLe ciel s'ouvre.",
    "Le serpent ne peut pas réguler\nsa propre température — il utilise\nle sol chaud et l'ombre des rochers\npour survivre à la chaleur du désert.",
    "Le Serpent",
    [10, 10, 20],
    [255, 220, 100],
    "eagle"
  );
});

// ─────────────────────────────────────────────────────────────────────────────
// LANCEMENT
// ─────────────────────────────────────────────────────────────────────────────

go("start");